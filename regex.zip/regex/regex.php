<?php

include 'const.php';

$error = SUCCESS_CODE;

$filename = "";
$pattern = "";
$result = array();
$response = array();

// FILL IN YOUR CODE BELOW

$error = "";
$patternSet = 0;
$fileSet = 0;

if (isset($_GET["filename"])){
    $filename = $_GET["filename"];
    $fileSet = 1;
}

if (isset($_GET["pattern"])){
    $pattern = $_GET["pattern"];
    $patternSet = 1;
}

if ($_SERVER["REQUEST_METHOD"] === 'GET'){
    $error = $error . 0;
} else {
    $error = $error . 1;
}

if($patternSet === 1){
    $error = $error . 0;
} else {
    $error = $error . 1;
}

if($fileSet === 1){
    $error = $error . 0;
} else {
    $error = $error . 1;
}

$filename = "uploads/" . $filename;

//file not found case
if(file_exists($filename)){
    $error = $error . 0;
} else {
    $error = $error . 1;
}
    
$stringValid = !str_contains($error,"1");

if ($stringValid) {
    $lines = file($filename);
    foreach ($lines as $line_num => $line) {
        $line = str_replace("\n", '', $line); // remove new lines
        $line = str_replace("\r", '', $line); // remove carriage returns
        array_push($result, $line);
    }
}

$errorInt = 0;
for ($i = 0; $i < strlen($error); $i++){
    $char = substr($error, $i, 1);
    if($char === "1"){
        $errorInt = $errorInt + pow(2,$i);
    }
}
$error = $errorInt;

// FILL IN YOUR CODE ABOVE

$response["status_code"] = $error;
$response["pattern"] = $pattern;
$response["result_sets"] = $result;
header('Content-Type: application/json; charset=utf-8');
echo json_encode($response);

?>