function upload_file()
{
    

    var regex_file = document.getElementById('regex_file');
    var status = document.getElementById('status');
    var result = document.getElementById('result');
	var file = regex_file.files[0];
	var form_data = new FormData();
	form_data.append("regex_file", file);
	var xhttp = new XMLHttpRequest();
	xhttp.open('POST', './upload.php', true);
    

	xhttp.onload = function()
	{
		if (xhttp.status == 200)
		{
			var json_data = JSON.parse(this.responseText, function (key, value) { return value; });
			status.innerHTML = json_data; // json_data is [object Object]
			// FILL IN YOUR CODE BELOW
            
            var form = document.getElementById("regex_form")

            const node1 = document.createElement("li")
            const textNode1 = document.createTextNode("status code = " + json_data.status_code)
            node1.appendChild(textNode1)

            const node2 = document.createElement("li")
            const textNode2 = document.createTextNode("pattern = " + json_data.pattern)
            node2.appendChild(textNode2)
            
            const node3 = document.createElement("li")
            const textNode3 = document.createTextNode("result_sets = " + json_data.result_sets)
            node3.appendChild(textNode3)

            //form.appendChild(node1)
            //form.appendChild(node2)
            //form.appendChild(node3)
			
			

            xhttp.open("POST", "upload.php")
			// FILL IN YOUR CODE ABOVE
		}
	};

	// send the data.
	xhttp.send(form_data);
}

function match_pattern()
{
    var regex_file = document.getElementById('regex_file');
    var regex_text = document.getElementById('regex_text');
    var status = document.getElementById('status');
    var result = document.getElementById('result');
    if (regex_file.files.length == 0)
    	return false;
	var xhttp = new XMLHttpRequest();
	xhttp.open('GET', './regex.php?filename=' + regex_file.files[0].name + '&pattern=' + regex_text.value, true);
	xhttp.onload = function()
	{
		if (xhttp.status == 200)
		{
            
			var json_data = JSON.parse(this.responseText, function (key, value) { return value; });
			status.innerHTML = json_data; // json_data is [object Object]

			// FILL IN YOUR CODE BELOW

            
			var resultSetArr = json_data.result_sets
            var pattern = json_data.pattern;
            var status_code = json_data.status_code

            status.innerHTML = status_code


            var table = document.getElementsByTagName("table")
            table = table[0]

            
            var tableLength = table.rows.length

            
            //remove old rows
            for(var i = 3; i < tableLength; i++){
                table.deleteRow(3)
            }


            //get regex matches? Or just coler them?

            for(var i = 0; i < resultSetArr.length; i++){
                var row = table.insertRow(-1)

                var numData = row.insertCell(-1)
                numData.innerText = (i+1)

                var result = resultSetArr[i]

                var textData = row.insertCell(-1)
                textData.innerText = result

                if(result.search(pattern) != -1){
                    textData.style.backgroundColor = "turquoise"
                } else {
                    textData.style.backgroundColor = "salmon"
                }
                
                
                

            }
			
			// FILL IN YOUR CODE ABOVE
		}
	};

	// send the data.
	xhttp.send();
}

// this method is reserved for extra credit
function hide_unmatched_results()
{
	// FILL IN YOUR CODE BELOW
	// ...
	// ...
	// ...
	// FILL IN YOUR CODE ABOVE
}

document.getElementById('submit').onclick = upload_file;
document.getElementById('filter').onchange = hide_unmatched_results;


