<?php

include 'const.php';

$error = SUCCESS_CODE;
$result = array();
$response = array();

// HINT: https://www.php.net/manual/en/features.file-upload.post-method.php
// FILL IN YOUR CODE BELOW

$error = "";

if ($_SERVER["REQUEST_METHOD"] === 'POST'){
    $error = $error . 0;
} else {
    $error = $error . 1;
}

$uploaddir = 'uploads/';
$uploadfile = $uploaddir . basename($_FILES['regex_file']['name']);

$imageFileType = strtolower(pathinfo($uploadfile,PATHINFO_EXTENSION));

if (move_uploaded_file($_FILES['regex_file']['tmp_name'], $uploadfile)) {
    $error = $error . 0;
} else {
    $error = $error . 1;
}

if($imageFileType === "txt"){
    $error = $error . 0;
} else {
    $error = $error . 1;
}

$stringValid = !str_contains($error,"1");

//if ($stringValid) {
  //  $lines = file($filename);
    //foreach ($lines as $line_num => $line) {
      //  $line = str_replace("\n", '', $line); // remove new lines
        //$line = str_replace("\r", '', $line); // remove carriage returns
        //array_push($result, $line);
    //}
//}

$errorInt = 0;
for ($i = 0; $i < strlen($error); $i++){
    $char = substr($error, $i, 1);
    if($char === "1"){
        $errorInt = $errorInt + pow(2,$i);
    }
}
$error = $errorInt;


// FILL IN YOUR CODE ABOVE

$response["status_code"] = $error;
$response["result_sets"] = $result;
header('Content-Type: application/json; charset=utf-8');
echo json_encode($response);